char CodeToChar (char key[]);

char * CharToCode (char key);